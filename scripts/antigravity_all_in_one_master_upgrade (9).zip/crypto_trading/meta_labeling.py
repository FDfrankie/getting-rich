"""Triple-Barrier Labeling, Meta-Labeling Filter, and Volatility-Targeted Momentum.

References:
- Lopez de Prado (AFML): Triple-Barrier Method & Meta-Labeling (separates directional signal from bet sizing/filtering).
- Barroso & Santa-Clara / Learning-to-Rank (arXiv:2012.07149): Risk-adjusted momentum & inverse-volatility scaling.
"""
from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd


def compute_triple_barrier_labels(
    close: pd.Series,
    *,
    pt_mult: float = 2.0,
    sl_mult: float = 1.5,
    max_hold_bars: int = 12,
    vol_window: int = 24,
) -> pd.DataFrame:
    """Label each bar (+1: profit-take hit first, -1: stop-loss hit first, 0: vertical time barrier)."""
    c = pd.to_numeric(close, errors="coerce").to_numpy(dtype=float)
    ret = pd.Series(c).pct_change().fillna(0.0)
    vol = ret.rolling(vol_window, min_periods=max(5, vol_window // 2)).std(ddof=1).fillna(0.005).clip(lower=0.001).to_numpy()
    n = len(c)
    labels = np.zeros(n, dtype=int)
    tb_rets = np.zeros(n, dtype=float)
    hold_bars = np.zeros(n, dtype=int)

    for i in range(n - 1):
        entry = c[i]
        if not np.isfinite(entry) or entry <= 0:
            continue
        up_thr = entry * (1.0 + pt_mult * vol[i])
        dn_thr = entry * (1.0 - sl_mult * vol[i])
        end_j = min(n - 1, i + max_hold_bars)
        hit = 0
        exit_j = end_j
        for j in range(i + 1, end_j + 1):
            if c[j] >= up_thr:
                hit = 1
                exit_j = j
                break
            if c[j] <= dn_thr:
                hit = -1
                exit_j = j
                break
        labels[i] = hit
        tb_rets[i] = (c[exit_j] - entry) / entry
        hold_bars[i] = exit_j - i

    return pd.DataFrame({"tb_label": labels, "tb_return": tb_rets, "tb_hold_bars": hold_bars}, index=close.index)


def apply_meta_label_filter(
    primary_signals: np.ndarray,
    features: pd.DataFrame,
    *,
    min_adx: float = 18.0,
    max_vol_z: float = 3.0,
    target_ann_vol: float = 0.35,
    bars_per_year: float = 24.0 * 365.0,
) -> dict[str, Any]:
    """Secondary Meta-Labeling & Volatility-Targeting layer sizing/filtering primary directional signals."""
    sig = np.asarray(primary_signals, dtype=float)
    n = len(sig)
    close = pd.to_numeric(features["Close"], errors="coerce") if "Close" in features.columns else pd.Series(np.ones(n))
    ret1 = close.pct_change().fillna(0.0)
    realized_ann_vol = (ret1.rolling(24, min_periods=6).std(ddof=1).fillna(0.01) * np.sqrt(bars_per_year)).clip(lower=0.05).to_numpy()
    vol_scalar = np.clip(target_ann_vol / realized_ann_vol, 0.25, 1.5)

    adx_ok = np.ones(n, dtype=bool)
    if "adx_14" in features.columns:
        adx_ok = features["adx_14"].fillna(20.0).to_numpy() >= min_adx

    vol_ok = np.ones(n, dtype=bool)
    if "volume_zscore_24" in features.columns:
        vol_ok = features["volume_zscore_24"].fillna(0.0).abs().to_numpy() <= max_vol_z

    meta_prob = np.where(adx_ok & vol_ok, 0.65, 0.35)
    filtered_weights = np.where(meta_prob >= 0.5, sig * vol_scalar, 0.0)
    filtered_weights = np.clip(filtered_weights, -1.0, 1.0)
    return {
        "filtered_weights": filtered_weights,
        "meta_probability": meta_prob,
        "vol_scalar": vol_scalar,
        "pass_rate": round(float(np.mean(meta_prob >= 0.5)), 4) if n > 0 else 0.0,
    }


def risk_adjusted_momentum_rank(panel_df: pd.DataFrame, *, lookback: int = 24) -> pd.Series:
    """Compute cross-sectional Sharpe-adjusted momentum score (return / realized_vol) per symbol."""
    close = pd.to_numeric(panel_df["Close"], errors="coerce")
    ret = close.pct_change(lookback)
    vol = close.pct_change(1).rolling(lookback, min_periods=max(5, lookback // 2)).std(ddof=1).replace(0, np.nan)
    return (ret / (vol * np.sqrt(lookback))).fillna(0.0)
